// JavaScript Document
$(function() {
	var img_Width;
	var img_Height
	$(".tobigimages img").live("click",function() {
				var img = new Image();
				img.src = this.src;
				img_Width = img.width;
				img_Height = img.height;
				$(".big img").attr("src",this.src);
				if(img.height>=$(window).height()){
					img_Height = $(window).height()-60;
					img_Width = img_Height*img_Width/img.height;
					}
				showDialog(img_Width, img_Height);
				$(".big").show(); //显示对话框
				$(".mask").height($(document).height())
				$(".mask").show(); //显示背景色
				
		});	//$("div img").live

	$(window).resize(function() {//页面窗口大小改变事件
                if (!$(".big").is(":visible")) {
                    return;
                }
                showDialog(img_Width, img_Height);
		});//$(window).resize

	$(".big a").live("click",function() {
                $(".big").hide();//隐藏图片
				$(".mask").hide();
				//$("body").css("overflow","visible");
		});

});//ready
		//显示对话框
	function showDialog(width, height){
				$(".big").css("width",width);
				$(".big").css("height",height);
				//alert("height: " + height + " window.height: " + $(window).height() );
				if(height > $(window).height())//$(window).height()浏览器可视区域的高度
				{
					$(".big").css({ "left": getCenterX($(".big")), "top": getTopY()});
				}
				else
				{
					$(".big").css({ "left": getCenterX($(".big")), "top": getCenterY($(".big"))});
				}
	}

	//获取obj元素在屏幕中央时的左上角X坐标
	function getCenterX(obj){
				var win_Width = $(window).width();
				var obj_Width = obj.width();
				var scr_Left = $(window).scrollLeft();
				return scr_Left + (win_Width - obj_Width) / 2;
	}

	//获取obj元素在屏幕中央时的左上角Y坐标
	function getCenterY(obj){
				var win_Height = $(window).height();
				var obj_Height = obj.height();
				var scr_Top = $(window).scrollTop();
				return scr_Top + (win_Height - obj_Height) / 2;
	}
			
	//获取obj元素在屏幕最上边时的左上角Y坐标
	function getTopY(){
				var scr_Top = $(window).scrollTop();//获取元素相对滚动条顶部的偏移量
				//alert("windos.height: " + win_Height + " scrollTop: " + scr_Top);
	return scr_Top;
			}